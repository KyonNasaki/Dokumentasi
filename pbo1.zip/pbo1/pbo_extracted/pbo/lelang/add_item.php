<?php
include 'db.php';

/**
 * Flow mapping (Activity Diagram):
 * Seller → Menentukan harga → System Menyimpan data Harga → Admin Index Barang Legal
 * New items are inserted as 'pending_legal'. Admin must mark them 'legal' before they appear in market.
 * Optional global price bounds (table: settings) are enforced if present.
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $seller = mysqli_real_escape_string($conn, $_POST['seller'] ?? '');
    $name   = mysqli_real_escape_string($conn, $_POST['name'] ?? '');
    $desc   = mysqli_real_escape_string($conn, $_POST['desc'] ?? '');
    $price  = intval($_POST['price'] ?? 0);

    if ($seller && $name && $desc && $price > 0) {
        // Check optional price bounds from settings
        $limit = mysqli_query($conn, "SELECT min_price, max_price FROM settings LIMIT 1");
        if ($limit && mysqli_num_rows($limit) === 1) {
            $bounds = mysqli_fetch_assoc($limit);
            $minp = intval($bounds['min_price'] ?? 0);
            $maxp = intval($bounds['max_price'] ?? 0);
            if (($minp && $price < $minp) || ($maxp && $price > $maxp)) {
                echo json_encode(['success'=>false,'msg'=>"Harga di luar batas yang ditentukan admin (min: $minp, max: $maxp)."]);
                exit;
            }
        }

        // Insert as pending_legal; will be shown after admin marks legal
        $sql = "INSERT INTO items (seller, name, description, price, status, legal) 
                VALUES ('$seller', '$name', '$desc', $price, 'pending_legal', 0)";
        if (mysqli_query($conn, $sql)) {
            echo json_encode(['success' => true, 'msg' => 'Barang ditambahkan dan menunggu verifikasi legal oleh Admin.']);
        } else {
            echo json_encode(['success' => false, 'msg' => 'Gagal menambah barang']);
        }
    } else {
        echo json_encode(['success' => false, 'msg' => 'Data tidak lengkap']);
    }
} else {
    echo json_encode(['success' => false, 'msg' => 'Metode tidak valid']);
}
?>
