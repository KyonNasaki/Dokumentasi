<?php
include 'db.php';

// Rekomendasi: barang aktif yang belum pernah di-bid oleh user (atau semua barang aktif)
$where = "WHERE status='aktif'";
if (isset($_GET['username'])) {
    $username = mysqli_real_escape_string($conn, $_GET['username']);
    // Contoh: filter barang yang belum pernah di-bid user
    $where .= " AND id NOT IN (SELECT item_id FROM bids WHERE username='$username')";
}
if (isset($_GET['seller'])) {
    $seller = mysqli_real_escape_string($conn, $_GET['seller']);
    $where .= " AND seller='$seller'";
}
$sql = "SELECT * FROM items $where ORDER BY id DESC LIMIT 4";
$result = mysqli_query($conn, $sql);

$items = [];
while ($row = mysqli_fetch_assoc($result)) {
    $items[] = $row;
}
echo json_encode($items);
?>
