<?php
// Konfigurasi database
$host = "localhost";
$user = "root";
$pass = ""; // Sebaiknya ganti dengan password MySQL kamu
$db   = "lelang_db";

// Membuat koneksi
$conn = mysqli_connect($host, $user, $pass, $db);

// Cek koneksi
if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
?>

