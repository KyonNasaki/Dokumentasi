<?php
include 'db.php';
$result = mysqli_query($conn, "SELECT * FROM items WHERE status='aktif' AND legal=1 ORDER BY id DESC");
$items = [];
while ($row = mysqli_fetch_assoc($result)) {
    $items[] = $row;
}
echo json_encode($items);
?>