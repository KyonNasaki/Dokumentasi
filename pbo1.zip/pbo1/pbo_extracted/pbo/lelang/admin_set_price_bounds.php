<?php
include 'db.php';
/**
 * Admin → Menentukan batasan harga
 * Request: POST min_price, max_price (opsional keduanya). Stored in single-row 'settings' table.
 */
if ($_SERVER['REQUEST_METHOD']==='POST'){
    $min_price = isset($_POST['min_price']) ? intval($_POST['min_price']) : 0;
    $max_price = isset($_POST['max_price']) ? intval($_POST['max_price']) : 0;

    // Ensure settings row exists
    mysqli_query($conn, "CREATE TABLE IF NOT EXISTS settings (id INT PRIMARY KEY DEFAULT 1, min_price INT DEFAULT 0, max_price INT DEFAULT 0)");
    $exists = mysqli_query($conn, "SELECT id FROM settings WHERE id=1");
    if ($exists && mysqli_num_rows($exists)===1){
        $ok = mysqli_query($conn, "UPDATE settings SET min_price=$min_price, max_price=$max_price WHERE id=1");
    } else {
        $ok = mysqli_query($conn, "INSERT INTO settings (id,min_price,max_price) VALUES (1,$min_price,$max_price)");
    }
    if ($ok){
        echo json_encode(['success'=>true]);
    } else {
        echo json_encode(['success'=>false,'msg'=>'Gagal menyimpan batasan harga']);
    }
} else {
    echo json_encode(['success'=>false,'msg'=>'Metode tidak valid']);
}
?>