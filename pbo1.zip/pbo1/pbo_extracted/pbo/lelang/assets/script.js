document.addEventListener('DOMContentLoaded', function() {
    // Login logic
    const loginSection = document.getElementById('login-section');
    const loginForm = document.getElementById('login-form');
    const loginMessage = document.getElementById('login-message');
    const dashboardUserAdmin = document.getElementById('dashboard-useradmin');
    const dashboardSeller = document.getElementById('dashboard-seller');
    const logoutBtnUserAdmin = document.getElementById('logout-btn-useradmin');
    const logoutBtnSeller = document.getElementById('logout-btn-seller');

    let currentRole = null;

    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value.trim();
        const role = document.getElementById('role').value;

        fetch('login.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}&role=${encodeURIComponent(role)}`
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                if (data.role === 'user') {
                    window.location.href = 'home_user.html';
                } else if (data.role === 'admin') {
                    window.location.href = 'home_admin.html';
                } else if (data.role === 'seller') {
                    window.location.href = 'home_seller.html';
                }
            } else {
                loginMessage.textContent = data.msg;
                loginMessage.style.color = '#d9534f';
            }
        })
        .catch(() => {
            loginMessage.textContent = 'Terjadi kesalahan koneksi!';
            loginMessage.style.color = '#d9534f';
        });
    });

    // Logout logic
    if (logoutBtnUserAdmin) {
        logoutBtnUserAdmin.addEventListener('click', function() {
            dashboardUserAdmin.style.display = 'none';
            loginSection.style.display = 'block';
            currentRole = null;
        });
    }
    if (logoutBtnSeller) {
        logoutBtnSeller.addEventListener('click', function() {
            dashboardSeller.style.display = 'none';
            loginSection.style.display = 'block';
            currentRole = null;
        });
    }

    // Auction logic for user/admin only
    const startPrice = 1000000;
    let highestBid = startPrice;
    const bidInput = document.getElementById('bid-input');
    const bidBtn = document.getElementById('bid-btn');
    const highestBidSpan = document.getElementById('highest-bid');
    const bidMessage = document.getElementById('bid-message');

    if (bidBtn) {
        bidBtn.addEventListener('click', function() {
            const bidValue = parseInt(bidInput.value);
            if (isNaN(bidValue) || bidValue <= highestBid) {
                bidMessage.textContent = 'Penawaran harus lebih tinggi dari penawaran tertinggi!';
                bidMessage.style.color = '#d9534f';
            } else {
                highestBid = bidValue;
                highestBidSpan.textContent = 'Rp ' + highestBid.toLocaleString('id-ID');
                bidMessage.textContent = 'Penawaran berhasil!';
                bidMessage.style.color = 'green';
                bidInput.value = '';
            }
        });
    }

    // Seller logic: add item (kirim ke database)
    const addItemForm = document.getElementById('add-item-form');
    const itemsList = document.getElementById('items-list');
    if (addItemForm) {
        addItemForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const name = document.getElementById('item-name').value.trim();
            const desc = document.getElementById('item-desc-input').value.trim();
            const price = document.getElementById('item-price').value.trim();
            // Ganti 'ken' dengan session/username seller sebenarnya jika sudah login
            const seller = 'ken';
            if (name && desc && price) {
                fetch('add_item.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `seller=${encodeURIComponent(seller)}&name=${encodeURIComponent(name)}&desc=${encodeURIComponent(desc)}&price=${encodeURIComponent(price)}`
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        // Tambahkan ke list seller tanpa reload
                        const li = document.createElement('li');
                        li.textContent = `${name} - ${desc} (Rp ${parseInt(price).toLocaleString('id-ID')})`;
                        itemsList.appendChild(li);
                        addItemForm.reset();
                    } else {
                        alert(data.msg || 'Gagal menambah barang');
                    }
                });
            }
        });
    }

    // User logic: tampilkan daftar barang dari database
    const userItemsList = document.getElementById('user-items-list');
    if (userItemsList) {
        fetch('get_items.php')
            .then(res => res.json())
            .then(items => {
                userItemsList.innerHTML = '';
                if (items.length === 0) {
                    userItemsList.innerHTML = '<li>Tidak ada barang lelang aktif.</li>';
                } else {
                    items.forEach(item => {
                        const li = document.createElement('li');
                        li.innerHTML = `<strong>${item.name}</strong> - ${item.description} <br>Harga Awal: Rp ${parseInt(item.price).toLocaleString('id-ID')} <br><em>Seller: ${item.seller}</em>`;
                        userItemsList.appendChild(li);
                    });
                }
            });
        // Riwayat penawaran
        fetch('get_bids.php?username=ken')
            .then(res => res.json())
            .then(bids => {
                const tbody = document.getElementById('user-bid-history');
                if (tbody) {
                    tbody.innerHTML = '';
                    if (bids.length === 0) {
                        tbody.innerHTML = '<tr><td colspan="3">Belum ada riwayat penawaran.</td></tr>';
                    } else {
                        bids.forEach(bid => {
                            const tr = document.createElement('tr');
                            tr.innerHTML = `<td style="padding:8px;">${bid.item_name}</td><td style="padding:8px;">Rp ${parseInt(bid.amount).toLocaleString('id-ID')}</td><td style="padding:8px;">${bid.status}</td>`;
                            tbody.appendChild(tr);
                        });
                    }
                }
            });
        // Rekomendasi lelang
        fetch('get_rekomendasi.php?username=ken')
            .then(res => res.json())
            .then(items => {
                const rekomDiv = document.getElementById('user-rekomendasi');
                if (rekomDiv) {
                    rekomDiv.innerHTML = '';
                    if (items.length === 0) {
                        rekomDiv.innerHTML = '<div>Tidak ada rekomendasi lelang.</div>';
                    } else {
                        items.forEach(item => {
                            const box = document.createElement('div');
                            box.style = "background:#181818;padding:12px;border-radius:8px;flex:1;margin-right:8px;";
                            box.innerHTML = `<img src="images/item1.jpg" alt="${item.name}" style="width:100%;border-radius:6px;"><p style="margin:8px 0 0 0;">${item.name}</p><button style="margin-top:8px;">Lihat Detail</button>`;
                            rekomDiv.appendChild(box);
                        });
                    }
                }
            });
    }

    // Admin logic: tampilkan daftar barang dari database dan riwayat penawaran
    const adminItemsList = document.getElementById('admin-items-list');
    if (adminItemsList) {
        fetch('get_items.php')
            .then(res => res.json())
            .then(items => {
                adminItemsList.innerHTML = '';
                if (items.length === 0) {
                    adminItemsList.innerHTML = '<li>Tidak ada barang lelang aktif.</li>';
                } else {
                    items.forEach(item => {
                        const li = document.createElement('li');
                        li.innerHTML = `<strong>${item.name}</strong> - ${item.description} <br>Harga Awal: Rp ${parseInt(item.price).toLocaleString('id-ID')} <br><em>Seller: ${item.seller}</em>`;
                        adminItemsList.appendChild(li);
                    });
                }
            });
        // Riwayat penawaran semua user
        fetch('get_bids.php')
            .then(res => res.json())
            .then(bids => {
                const tbody = document.getElementById('admin-bid-history');
                if (tbody) {
                    tbody.innerHTML = '';
                    if (bids.length === 0) {
                        tbody.innerHTML = '<tr><td colspan="4">Belum ada riwayat penawaran.</td></tr>';
                    } else {
                        bids.forEach(bid => {
                            const tr = document.createElement('tr');
                            tr.innerHTML = `<td style="padding:8px;">${bid.username}</td><td style="padding:8px;">${bid.item_name}</td><td style="padding:8px;">Rp ${parseInt(bid.amount).toLocaleString('id-ID')}</td><td style="padding:8px;">${bid.status}</td>`;
                            tbody.appendChild(tr);
                        });
                    }
                }
            });
        // Rekomendasi lelang (tampilkan semua barang aktif)
        fetch('get_rekomendasi.php')
            .then(res => res.json())
            .then(items => {
                const rekomDiv = document.getElementById('admin-rekomendasi');
                if (rekomDiv) {
                    rekomDiv.innerHTML = '';
                    if (items.length === 0) {
                        rekomDiv.innerHTML = '<div>Tidak ada rekomendasi lelang.</div>';
                    } else {
                        items.forEach(item => {
                            const box = document.createElement('div');
                            box.style = "background:#181818;padding:12px;border-radius:8px;flex:1;margin-right:8px;";
                            box.innerHTML = `<img src="images/item1.jpg" alt="${item.name}" style="width:100%;border-radius:6px;"><p style="margin:8px 0 0 0;">${item.name}</p><button style="margin-top:8px;">Lihat Detail</button>`;
                            rekomDiv.appendChild(box);
                        });
                    }
                }
            });
    }

    // Seller logic: tampilkan riwayat penawaran barang seller dan rekomendasi
    const sellerRekomDiv = document.getElementById('seller-rekomendasi');
    if (sellerRekomDiv) {
        fetch('get_rekomendasi.php?seller=ken')
            .then(res => res.json())
            .then(items => {
                sellerRekomDiv.innerHTML = '';
                if (items.length === 0) {
                    sellerRekomDiv.innerHTML = '<div>Tidak ada rekomendasi lelang.</div>';
                } else {
                    items.forEach(item => {
                        const box = document.createElement('div');
                        box.style = "background:#181818;padding:12px;border-radius:8px;flex:1;margin-right:8px;";
                        box.innerHTML = `<img src="images/item1.jpg" alt="${item.name}" style="width:100%;border-radius:6px;"><p style="margin:8px 0 0 0;">${item.name}</p><button style="margin-top:8px;">Lihat Detail</button>`;
                        sellerRekomDiv.appendChild(box);
                    });
                }
            });
    }
});
