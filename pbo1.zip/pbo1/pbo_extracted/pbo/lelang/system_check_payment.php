<?php
include 'db.php';
/**
 * System → Pengecekan Pembayaran → Dikenakan Pajak
 * Request: POST payment_id, ok (1/0)
 * If ok, mark payment 'paid', apply simple 10% tax into revenues table.
 */
if ($_SERVER['REQUEST_METHOD']==='POST'){
    $payment_id = intval($_POST['payment_id'] ?? 0);
    $ok = intval($_POST['ok'] ?? 0);
    if ($payment_id>0){
        if ($ok){
            mysqli_query($conn, "UPDATE payments SET status='paid' WHERE id=$payment_id");
            // Tax handling: compute tax = 10% of bid amount
            $q = mysqli_query($conn, "SELECT p.id, b.amount, i.seller FROM payments p 
                JOIN bids b ON p.bid_id=b.id 
                JOIN items i ON b.item_id=i.id 
                WHERE p.id=$payment_id");
            if ($row = mysqli_fetch_assoc($q)){
                $amount = intval($row['amount']);
                $seller = mysqli_real_escape_string($conn, $row['seller']);
                $tax = intval(round($amount * 0.10));
                // store revenue to be released to seller net of tax
                $net = $amount - $tax;
                mysqli_query($conn, "INSERT INTO revenues (payment_id, seller, gross, tax, net, status) VALUES ($payment_id,'$seller',$amount,$tax,$net,'awaiting_shipment')");
            }
            echo json_encode(['success'=>true]);
        } else {
            mysqli_query($conn, "UPDATE payments SET status='failed' WHERE id=$payment_id");
            echo json_encode(['success'=>true,'msg'=>'Pembayaran ditolak']);
        }
    } else {
        echo json_encode(['success'=>false,'msg'=>'payment_id tidak valid']);
    }
} else {
    echo json_encode(['success'=>false,'msg'=>'Metode tidak valid']);
}
?>