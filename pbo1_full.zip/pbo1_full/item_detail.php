<?php
require __DIR__.'/config.php';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id<=0){ http_response_code(400); exit('ID tidak valid'); }
$stmt = $pdo->prepare("SELECT * FROM items WHERE id = :id");
$stmt->execute([':id'=>$id]);
$item = $stmt->fetch();
if(!$item){ http_response_code(404); exit('Item tidak ditemukan'); }
$title = "Detail Item #".$item['id'];
include __DIR__.'/header.php';
?>
  <a class="btn" href="items_index.php">← Kembali</a>
  <h1><?= htmlspecialchars($item['name']) ?></h1>
  <div class="card grid">
    <div><strong>Seller:</strong> <?= htmlspecialchars($item['seller']) ?></div>
    <div><strong>Harga awal:</strong> Rp <?= number_format($item['price'],0,',','.') ?></div>
    <div><strong>Status:</strong> <span class="chip <?= $item['status']==='aktif'?'aktif':'selesai' ?>"><?= htmlspecialchars($item['status']) ?></span></div>
    <div><strong>Deskripsi:</strong><br><span class="muted"><?= nl2br(htmlspecialchars($item['description'])) ?></span></div>
  </div>
<?php include __DIR__.'/footer.php'; ?>
