<?php
require __DIR__.'/config.php';
require __DIR__.'/auth.php';
require_role(['admin','seller']);
<?php
require __DIR__.'/config.php';
$errors = []; $success = false;
if ($_SERVER['REQUEST_METHOD']==='POST'){
  $name = trim($_POST['name'] ?? '');
  $seller = trim($_POST['seller'] ?? '');
  $description = trim($_POST['description'] ?? '');
  $price = (int)($_POST['price'] ?? 0);
  $status = $_POST['status'] ?? 'aktif';
  if($name==='') $errors[]='Nama wajib.';
  if($seller==='') $errors[]='Seller wajib.';
  if($price<=0) $errors[]='Harga harus > 0.';
  if(!in_array($status,['aktif','selesai'])) $errors[]='Status tidak valid.';
  if(!$errors){
    $stmt = $pdo->prepare("INSERT INTO items (seller,name,description,price,status) VALUES (:seller,:name,:description,:price,:status)");
    $stmt->execute([':seller'=>$seller,':name'=>$name,':description'=>$description,':price'=>$price,':status'=>$status]);
    header('Location: items_index.php'); exit;
  }
}
$title = "Tambah Item";
include __DIR__.'/header.php';
?>
  <h1><?= htmlspecialchars($title) ?></h1>
  <div class="card">
    <?php if($errors): ?><div class="muted">• <?= implode('<br>• ',array_map('htmlspecialchars',$errors)) ?></div><?php endif; ?>
    <form method="post">
      <div class="row">
        <div>
          <label>Nama Item</label>
          <input name="name" required>
        </div>
        <div>
          <label>Seller</label>
          <input name="seller" required>
        </div>
      </div>
      <div class="row">
        <div>
          <label>Harga Awal</label>
          <input type="number" name="price" min="1" required>
        </div>
        <div>
          <label>Status</label>
          <select name="status">
            <option value="aktif">aktif</option>
            <option value="selesai">selesai</option>
          </select>
        </div>
      </div>
      <div class="row row-1">
        <div>
          <label>Deskripsi</label>
          <textarea name="description" rows="4"></textarea>
        </div>
      </div>
      <button class="btn btn-primary mt-3" type="submit">Simpan</button>
      <a class="btn mt-3" href="items_index.php">Batal</a>
    </form>
  </div>
<?php include __DIR__.'/footer.php'; ?>
