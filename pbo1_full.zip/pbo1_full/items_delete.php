<?php
require __DIR__.'/config.php';
require __DIR__.'/auth.php';
require_role(['admin','seller']);
<?php
require __DIR__.'/config.php';
if($_SERVER['REQUEST_METHOD']!=='POST'){ http_response_code(405); exit('Method not allowed'); }
$id = (int)($_POST['id'] ?? 0);
if($id<=0){ http_response_code(400); exit('ID tidak valid'); }
$stmt = $pdo->prepare("DELETE FROM items WHERE id=:id");
$stmt->execute([':id'=>$id]);
header('Location: items_index.php');
