<?php
require __DIR__.'/config.php';
require __DIR__.'/auth.php';
require_role(['admin']);
<?php
require __DIR__.'/config.php';
$title = "Daftar Pengguna";
$stmt = $pdo->query("SELECT id, username, role FROM users ORDER BY id DESC");
$users = $stmt->fetchAll();
include __DIR__.'/header.php';
?>
  <h1><?= htmlspecialchars($title) ?></h1>
  <div class="toolbar">
    <a class="btn btn-primary" href="users_create.php">+ Tambah User</a>
  </div>
  <div class="card">
    <table>
      <thead><tr><th>ID</th><th>Username</th><th>Role</th><th>Aksi</th></tr></thead>
      <tbody>
        <?php if(!$users): ?>
          <tr><td colspan="4" class="muted">Belum ada user.</td></tr>
        <?php else: foreach($users as $u): ?>
          <tr>
            <td><?= $u['id'] ?></td>
            <td><?= htmlspecialchars($u['username']) ?></td>
            <td><?= htmlspecialchars($u['role']) ?></td>
            <td style="white-space:nowrap">
              <a class="btn" href="users_edit.php?id=<?= $u['id'] ?>">Edit</a>
              <form action="users_delete.php" method="post" style="display:inline" onsubmit="return confirm('Hapus user ini?')">
                <input type="hidden" name="id" value="<?= $u['id'] ?>">
                <button class="btn btn-warn" type="submit">Hapus</button>
              </form>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
<?php include __DIR__.'/footer.php'; ?>
