<?php
require __DIR__.'/config.php';
$seller = $_GET['seller'] ?? '';
$stmt = $pdo->prepare("SELECT * FROM items WHERE seller = :seller");
$stmt->execute([':seller'=>$seller]);
$items = $stmt->fetchAll();
?>
<!doctype html>
<html lang="id">
<head><meta charset="utf-8"><title>Item Seller</title></head>
<body>
  <h1>Item milik <?= htmlspecialchars($seller) ?></h1>
  <ul>
    <?php foreach ($items as $it): ?>
      <li><?= htmlspecialchars($it['name']) ?> - Rp <?= number_format($it['price'],0,',','.') ?> (<?= $it['status'] ?>)</li>
    <?php endforeach; ?>
  </ul>
</body>
</html>