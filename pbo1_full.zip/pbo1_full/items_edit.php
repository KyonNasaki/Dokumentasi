<?php
require __DIR__.'/config.php';
require __DIR__.'/auth.php';
require_role(['admin','seller']);
<?php
require __DIR__.'/config.php';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT * FROM items WHERE id=:id");
$stmt->execute([':id'=>$id]);
$item = $stmt->fetch();
if(!$item){ http_response_code(404); exit('Item tidak ditemukan'); }
$errors=[];
if($_SERVER['REQUEST_METHOD']==='POST'){
  $name = trim($_POST['name'] ?? '');
  $seller = trim($_POST['seller'] ?? '');
  $description = trim($_POST['description'] ?? '');
  $price = (int)($_POST['price'] ?? 0);
  $status = $_POST['status'] ?? 'aktif';
  if($name==='') $errors[]='Nama wajib.';
  if($seller==='') $errors[]='Seller wajib.';
  if($price<=0) $errors[]='Harga harus > 0.';
  if(!in_array($status,['aktif','selesai'])) $errors[]='Status tidak valid.';
  if(!$errors){
    $stmt = $pdo->prepare("UPDATE items SET seller=:seller,name=:name,description=:description,price=:price,status=:status WHERE id=:id");
    $stmt->execute([':seller'=>$seller,':name'=>$name,':description'=>$description,':price'=>$price,':status'=>$status,':id'=>$id]);
    header('Location: items_index.php'); exit;
  }
}
$title = "Edit Item #".$item['id'];
include __DIR__.'/header.php';
?>
  <h1><?= htmlspecialchars($title) ?></h1>
  <div class="card">
    <?php if($errors): ?><div class="muted">• <?= implode('<br>• ',array_map('htmlspecialchars',$errors)) ?></div><?php endif; ?>
    <form method="post">
      <div class="row">
        <div>
          <label>Nama Item</label>
          <input name="name" value="<?= htmlspecialchars($item['name']) ?>" required>
        </div>
        <div>
          <label>Seller</label>
          <input name="seller" value="<?= htmlspecialchars($item['seller']) ?>" required>
        </div>
      </div>
      <div class="row">
        <div>
          <label>Harga Awal</label>
          <input type="number" name="price" min="1" value="<?= (int)$item['price'] ?>" required>
        </div>
        <div>
          <label>Status</label>
          <select name="status">
            <option value="aktif" <?= $item['status']==='aktif'?'selected':'' ?>>aktif</option>
            <option value="selesai" <?= $item['status']==='selesai'?'selected':'' ?>>selesai</option>
          </select>
        </div>
      </div>
      <div class="row row-1">
        <div>
          <label>Deskripsi</label>
          <textarea name="description" rows="4"><?= htmlspecialchars($item['description']) ?></textarea>
        </div>
      </div>
      <button class="btn btn-primary mt-3" type="submit">Simpan</button>
      <a class="btn mt-3" href="items_index.php">Batal</a>
    </form>
  </div>
<?php include __DIR__.'/footer.php'; ?>
