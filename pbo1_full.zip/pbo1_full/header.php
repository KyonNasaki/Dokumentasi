<?php /* header.php */ 
require_once __DIR__.'/auth.php';
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?= htmlspecialchars($title ?? 'Lelang App') ?></title>
  <style>
    :root{--bg:#0f172a;--panel:#111827;--muted:#94a3b8;--line:#1f2937;--acc:#93c5fd;--ok:#065f46;--warn:#7f1d1d}
    *{box-sizing:border-box}
    body{font-family:system-ui,Arial,sans-serif;margin:24px;background:var(--bg);color:#e2e8f0}
    a{color:var(--acc);text-decoration:none}
    .container{max-width:1024px;margin:0 auto}
    .card{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:16px}
    .grid{display:grid;gap:16px}
    .toolbar{display:flex;gap:8px;flex-wrap:wrap;margin:12px 0;align-items:center;justify-content:space-between}
    .left, .right{display:flex;gap:8px;align-items:center}
    .btn{display:inline-block;padding:8px 12px;border-radius:10px;background:#0b1220;border:1px solid var(--line)}
    .btn-primary{background:#1d4ed8;border-color:#1e40af;color:#fff}
    .btn-warn{background:#7f1d1d;border-color:#7f1d1d;color:#fecaca}
    table{width:100%;border-collapse:collapse;background:var(--panel);border-radius:12px;overflow:hidden}
    th,td{padding:10px 12px;border-bottom:1px solid var(--line);vertical-align:top}
    th{background:#0b1220;text-align:left}
    input,select,textarea{width:100%;padding:10px;border-radius:10px;border:1px solid var(--line);background:#0b1220;color:#e2e8f0}
    label{display:block;margin:8px 0 6px;color:#cbd5e1}
    form .row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
    form .row-1{grid-template-columns:1fr}
    .chip{padding:2px 8px;border-radius:999px;font-size:12px}
    .aktif{background:#064e3b;color:#a7f3d0}
    .selesai{background:#3f1d2b;color:#fecaca}
    .muted{color:var(--muted)}
    .mt-2{margin-top:8px}.mt-3{margin-top:12px}.mt-4{margin-top:16px}
    .searchbar{display:flex;gap:8px}
  </style>
</head>
<body>
  <div class="container">
    <div class="toolbar">
      <div class="left">
        <a class="btn" href="items_index.php">Item</a>
        <a class="btn" href="users_index.php">Users</a>
      </div>
      <div class="right">
        <?php if(is_logged_in()): $u = current_user(); ?>
          <span class="muted">Masuk sebagai <strong><?= htmlspecialchars($u['username']) ?></strong> (<?= htmlspecialchars($u['role']) ?>)</span>
          <a class="btn" href="logout.php">Logout</a>
        <?php else: ?>
          <a class="btn btn-primary" href="login.php">Login</a>
        <?php endif; ?>
      </div>
    </div>
