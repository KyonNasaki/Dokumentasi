<?php
require __DIR__.'/config.php';
require __DIR__.'/auth.php';
$title = "Daftar Item Lelang";

// search & filter
$q = trim($_GET['q'] ?? '');
$status = $_GET['status'] ?? '';

// pagination
$per_page = 10;
$page = max(1, (int)($_GET['page'] ?? 1));
$offset = ($page - 1) * $per_page;

// base query
$where = [];
$params = [];
if ($status === 'aktif' || $status === 'selesai') {
  $where[] = "status = :status";
  $params[':status'] = $status;
}
if ($q !== '') {
  $where[] = "(name LIKE :q OR description LIKE :q OR seller LIKE :q)";
  $params[':q'] = '%'.$q.'%';
}
// Seller: batasi hanya item miliknya
$isSeller = is_logged_in() && current_user()['role']==='seller';
if ($isSeller) {
  $where[] = "seller = :seller";
  $params[':seller'] = current_user()['username'];
}

$sql_where = $where ? (" WHERE ".implode(" AND ", $where)) : "";

// count
$stmt = $pdo->prepare("SELECT COUNT(*) c FROM items".$sql_where);
$stmt->execute($params);
$total = (int)$stmt->fetchColumn();

// data
$sql = "SELECT id, seller, name, description, price, status FROM items".$sql_where." ORDER BY id DESC LIMIT :limit OFFSET :offset";
$stmt = $pdo->prepare($sql);
foreach ($params as $k=>$v) { $stmt->bindValue($k, $v); }
$stmt->bindValue(':limit', $per_page, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$items = $stmt->fetchAll();

include __DIR__.'/header.php';
?>
  <h1><?= htmlspecialchars($title) ?></h1>
  <div class="card">
    <form class="searchbar" method="get">
      <input type="text" name="q" placeholder="Cari nama/desc/seller..." value="<?= htmlspecialchars($q) ?>">
      <select name="status">
        <option value="">Semua status</option>
        <option value="aktif" <?= $status==='aktif'?'selected':'' ?>>aktif</option>
        <option value="selesai" <?= $status==='selesai'?'selected':'' ?>>selesai</option>
      </select>
      <button class="btn">Cari</button>
      <?php if(is_logged_in() && (current_user()['role']==='admin' || current_user()['role']==='seller')): ?>
        <a class="btn btn-primary" href="items_create.php" style="margin-left:auto">+ Tambah Item</a>
      <?php endif; ?>
    </form>
  </div>

  <div class="card" style="margin-top:12px">
    <table>
      <thead>
        <tr>
          <th>ID</th><th>Nama</th><th>Seller</th><th>Deskripsi</th><th>Harga</th><th>Status</th><th>Aksi</th>
        </tr>
      </thead>
      <tbody>
      <?php if (!$items): ?>
        <tr><td colspan="7" class="muted">Tidak ada data.</td></tr>
      <?php else: foreach ($items as $it): ?>
        <tr>
          <td><?= $it['id'] ?></td>
          <td><a href="item_detail.php?id=<?= $it['id'] ?>"><?= htmlspecialchars($it['name']) ?></a></td>
          <td><?= htmlspecialchars($it['seller']) ?></td>
          <td><?= nl2br(htmlspecialchars($it['description'])) ?></td>
          <td>Rp <?= number_format($it['price'],0,',','.') ?></td>
          <td><span class="chip <?= $it['status']==='aktif'?'aktif':'selesai' ?>"><?= $it['status'] ?></span></td>
          <td style="white-space:nowrap">
            <?php if(is_logged_in() && (current_user()['role']==='admin' || (current_user()['role']==='seller' && current_user()['username']===$it['seller']))): ?>
              <a class="btn" href="items_edit.php?id=<?= $it['id'] ?>">Edit</a>
              <form action="items_delete.php" method="post" style="display:inline" onsubmit="return confirm('Hapus item ini?')">
                <input type="hidden" name="id" value="<?= $it['id'] ?>">
                <button class="btn btn-warn" type="submit">Hapus</button>
              </form>
            <?php else: ?>
              <span class="muted">—</span>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
    <?php
      $pages = max(1, (int)ceil($total / $per_page));
      if ($pages > 1):
    ?>
      <div class="toolbar" style="justify-content:center;margin-top:12px">
        <?php for($p=1; $p<=$pages; $p++): 
          $qs = $_GET; $qs['page']=$p; $url='?'.http_build_query($qs);
        ?>
          <a class="btn <?= $p==$page?'btn-primary':'' ?>" href="<?= $url ?>"><?= $p ?></a>
        <?php endfor; ?>
      </div>
    <?php endif; ?>
  </div>
<?php include __DIR__.'/footer.php'; ?>
