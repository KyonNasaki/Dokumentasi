<?php
require __DIR__.'/config.php';
require __DIR__.'/auth.php';

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = trim($_POST['username'] ?? '');
  $password = trim($_POST['password'] ?? '');
  if ($username === '' || $password === '') {
    $err = 'Username & password wajib.';
  } else {
    // NOTE: dump memakai plaintext. Untuk produksi gunakan password_hash/verify.
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :u AND password = :p LIMIT 1");
    $stmt->execute([':u'=>$username, ':p'=>$password]);
    $user = $stmt->fetch();
    if ($user) {
      $_SESSION['user'] = ['id'=>$user['id'], 'username'=>$user['username'], 'role'=>$user['role']];
      $next = $_GET['next'] ?? 'items_index.php';
      header('Location: '.$next);
      exit;
    } else {
      $err = 'Login gagal. Periksa akun Anda.';
    }
  }
}

$title = "Login";
include __DIR__.'/header.php';
?>
  <h1>Login</h1>
  <div class="card" style="max-width:480px">
    <?php if($err): ?><div class="muted" style="margin-bottom:8px"><?= htmlspecialchars($err) ?></div><?php endif; ?>
    <form method="post">
      <label>Username</label>
      <input name="username" autofocus>
      <label class="mt-2">Password</label>
      <input name="password" type="password">
      <button class="btn btn-primary mt-3" type="submit">Masuk</button>
      <a class="btn mt-3" href="items_index.php">Batal</a>
    </form>
  </div>
<?php include __DIR__.'/footer.php'; ?>
