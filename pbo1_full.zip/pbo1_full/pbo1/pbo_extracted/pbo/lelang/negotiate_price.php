<?php
include 'db.php';
/**
 * User ↔ Seller → Menawar Harga
 * Request: POST username, item_id, amount
 * Stores a bid with status 'pending_seller' for seller approval step.
 */
if ($_SERVER['REQUEST_METHOD']==='POST'){
    $username = mysqli_real_escape_string($conn, $_POST['username'] ?? '');
    $item_id  = intval($_POST['item_id'] ?? 0);
    $amount   = intval($_POST['amount'] ?? 0);
    if ($username && $item_id>0 && $amount>0){
        $sql = "INSERT INTO bids (username,item_id,amount,status) VALUES ('$username',$item_id,$amount,'pending_seller')";
        if (mysqli_query($conn,$sql)){
            echo json_encode(['success'=>true]);
        } else {
            echo json_encode(['success'=>false,'msg'=>'Gagal menawar']);
        }
    } else {
        echo json_encode(['success'=>false,'msg'=>'Data tidak lengkap']);
    }
} else {
    echo json_encode(['success'=>false,'msg'=>'Metode tidak valid']);
}
?>