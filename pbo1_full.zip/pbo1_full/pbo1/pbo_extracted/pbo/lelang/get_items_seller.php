<?php
include 'db.php';

$seller = isset($_GET['seller']) ? mysqli_real_escape_string($conn, $_GET['seller']) : '';
$items = [];
if ($seller) {
    // Ambil highest_bid dari tabel bids jika ada
    $sql = "SELECT i.*, 
                (SELECT MAX(amount) FROM bids WHERE item_id=i.id) AS highest_bid 
            FROM items i 
            WHERE i.seller='$seller' 
            ORDER BY i.id DESC";
    $result = mysqli_query($conn, $sql);
    while ($row = mysqli_fetch_assoc($result)) {
        $items[] = $row;
    }
}
echo json_encode($items);
?>
