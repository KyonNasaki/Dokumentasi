<?php
session_start();
include 'db.php';

// Pastikan hanya seller yang bisa akses
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'seller') {
    http_response_code(403);
    echo json_encode([]);
    exit;
}
$seller = $_SESSION['username'];

$result = mysqli_query($conn, "SELECT name, description, price, status FROM items WHERE seller='$seller'");
$data = [];
while ($row = mysqli_fetch_assoc($result)) {
    // highest_bid bisa diisi dengan price jika belum ada penawaran
    $row['highest_bid'] = $row['price'];
    $data[] = $row;
}
header('Content-Type: application/json');
echo json_encode($data);
?>
