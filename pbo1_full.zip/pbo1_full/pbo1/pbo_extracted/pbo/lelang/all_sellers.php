<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Daftar Semua Seller</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <header>
        <h1>Daftar Semua Seller</h1>
        <a href="home_admin.html" class="btn btn--ghost">Kembali ke Admin</a>
    </header>
    <main>
        <div class="table-wrapper">
            <table id="table-all-seller" class="table table--hover">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Username</th>
                        <th>Role</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Diisi otomatis dari database -->
                </tbody>
            </table>
        </div>
    </main>
    <script>
    function loadAllSellers() {
        fetch('api/get_accounts.php')
            .then(res => res.json())
            .then(data => {
                const tbody = document.querySelector('#table-all-seller tbody');
                tbody.innerHTML = '';
                data.sellers.forEach(seller => {
                    // Gunakan username jika nama tidak tersedia
                    const nama = seller.nama ? seller.nama : seller.username;
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${nama}</td>
                        <td>${seller.username}</td>
                        <td>${seller.role}</td>
                        <td>
                            <button class="btn btn--table btn--danger" onclick="deleteUserSeller('seller','${seller.username}')">Hapus</button>
                        </td>
                    `;
                    tbody.appendChild(tr);
                });
            });
    }
    window.onload = loadAllSellers;

    window.deleteUserSeller = function(type, username) {
        if (confirm('Yakin ingin menghapus akun ini?')) {
            fetch('api/delete_account.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ role: type, username })
            })
            .then(res => res.json())
            .then(result => {
                if (result.success) {
                    alert('Akun berhasil dihapus');
                    loadAllSellers();
                } else {
                    alert('Gagal menghapus: ' + result.message);
                }
            });
        }
    };
    </script>
</body>
</html>
