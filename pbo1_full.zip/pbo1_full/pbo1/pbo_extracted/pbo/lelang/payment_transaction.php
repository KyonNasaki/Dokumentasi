<?php
include 'db.php';
/**
 * User → Transaksi Pembayaran
 * Request: POST bid_id, method
 * Creates a payment record status='pending_check'
 */
if ($_SERVER['REQUEST_METHOD']==='POST'){
    $bid_id = intval($_POST['bid_id'] ?? 0);
    $method = mysqli_real_escape_string($conn, $_POST['method'] ?? 'transfer');
    if ($bid_id>0){
        $ok = mysqli_query($conn, "INSERT INTO payments (bid_id, method, status) VALUES ($bid_id,'$method','pending_check')");
        echo json_encode(['success'=>$ok?true:false]);
    } else {
        echo json_encode(['success'=>false,'msg'=>'bid_id tidak valid']);
    }
} else {
    echo json_encode(['success'=>false,'msg'=>'Metode tidak valid']);
}
?>