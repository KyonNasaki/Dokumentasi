<?php
include 'db.php';

// Proses form jika ada POST
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $seller = isset($_POST['seller']) ? mysqli_real_escape_string($conn, $_POST['seller']) : '';
    $name = isset($_POST['name']) ? mysqli_real_escape_string($conn, $_POST['name']) : '';
    $desc = isset($_POST['desc']) ? mysqli_real_escape_string($conn, $_POST['desc']) : '';
    $price = isset($_POST['price']) ? intval($_POST['price']) : 0;

    if ($seller && $name && $desc && $price > 0) {
        $sql = "INSERT INTO items (seller, name, description, price) VALUES ('$seller', '$name', '$desc', $price)";
        if (mysqli_query($conn, $sql)) {
            $msg = '<div style="color:green;margin-bottom:12px;">Barang berhasil ditambahkan!</div>';
        } else {
            $msg = '<div style="color:red;margin-bottom:12px;">Gagal menambah barang.</div>';
        }
    } else {
        $msg = '<div style="color:red;margin-bottom:12px;">Semua field harus diisi dan harga harus lebih dari 0.</div>';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Input Barang Seller</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <header>
        <h1>Input Barang Lelang (Seller)</h1>
    </header>
    <main>
        <section id="login-section">
            <h2>Form Input Barang</h2>
            <?php echo $msg; ?>
            <form method="post" action="">
                <label for="seller">Nama Seller:</label>
                <input type="text" id="seller" name="seller" required placeholder="Nama Seller">
                <label for="name">Nama Barang:</label>
                <input type="text" id="name" name="name" required placeholder="Nama Barang">
                <label for="desc">Deskripsi:</label>
                <input type="text" id="desc" name="desc" required placeholder="Deskripsi Barang">
                <label for="price">Harga Awal:</label>
                <input type="number" id="price" name="price" required min="1" placeholder="Harga Awal">
                <button type="submit">Simpan Barang</button>
            </form>
            <p style="text-align:center;margin-top:16px;">
                <a href="home_seller.html">Kembali ke Dashboard Seller</a>
            </p>
        </section>
    </main>
</body>
</html>
