<?php
include 'db.php';
/**
 * Seller → Menyetujui Pembayaran
 * Request: POST bid_id, approve (1/0)
 * If approved → status='approved', else 'rejected'.
 */
if ($_SERVER['REQUEST_METHOD']==='POST'){
    $bid_id = intval($_POST['bid_id'] ?? 0);
    $approve = intval($_POST['approve'] ?? 0);
    if ($bid_id>0){
        $status = $approve ? 'approved' : 'rejected';
        $ok = mysqli_query($conn, "UPDATE bids SET status='$status' WHERE id=$bid_id");
        echo json_encode(['success'=>$ok?true:false]);
    } else {
        echo json_encode(['success'=>false,'msg'=>'bid_id tidak valid']);
    }
} else {
    echo json_encode(['success'=>false,'msg'=>'Metode tidak valid']);
}
?>