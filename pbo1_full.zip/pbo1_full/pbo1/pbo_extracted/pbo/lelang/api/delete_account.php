<?php
header('Content-Type: application/json');
$data = json_decode(file_get_contents('php://input'), true);
$conn = new mysqli('localhost', 'root', '', 'lelang_db');
$username = $conn->real_escape_string($data['username']);
$role = $conn->real_escape_string($data['role']);
$result = $conn->query("DELETE FROM users WHERE username='$username' AND role='$role'");
if ($result) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => $conn->error]);
}
?>
