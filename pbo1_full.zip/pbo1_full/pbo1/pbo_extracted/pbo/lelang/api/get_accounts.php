<?php
header('Content-Type: application/json');
$conn = new mysqli('localhost', 'root', '', 'lelang_db');
if ($conn->connect_error) {
    echo json_encode(['users' => [], 'sellers' => [], 'error' => 'Koneksi database gagal']);
    exit;
}
$result = $conn->query("SELECT * FROM users");
if (!$result) {
    echo json_encode(['users' => [], 'sellers' => [], 'error' => 'Query gagal']);
    exit;
}
$users = [];
$sellers = [];
while($row = $result->fetch_assoc()) {
    // Gunakan username sebagai nama jika field nama tidak ada
    $nama = isset($row['nama']) && $row['nama'] ? $row['nama'] : $row['username'];
    if ($row['role'] == 'user') {
        $users[] = [
            'nama' => $nama,
            'username' => $row['username'],
            'role' => $row['role'],
            'status' => 'Aktif'
        ];
    } else if ($row['role'] == 'seller') {
        $sellers[] = [
            'nama' => $nama,
            'username' => $row['username'],
            'role' => $row['role'],
            'status' => 'Aktif'
        ];
    }
}
echo json_encode(['users' => $users, 'sellers' => $sellers]);
?>
