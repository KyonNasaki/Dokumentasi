

## Revisi – Sinkron dengan Activity Diagram

Perubahan kunci:
- **Admin menentukan barang legal** (`admin_mark_legal.php`) → item baru masuk `pending_legal` dan hanya tampil di market bila `legal=1` dan `status='aktif'`.
- **Admin menentukan batas harga** (`admin_set_price_bounds.php`) → `add_item.php` akan menolak harga di luar batas.
- **Negosiasi / Menawar harga** (`negotiate_price.php`) → menyimpan bid berstatus `pending_seller`.
- **Seller menyetujui pembayaran** (`seller_approve_payment.php`) → bila disetujui = `approved`.
- **Transaksi pembayaran** (`payment_transaction.php`) → membuat record pembayaran `pending_check`.
- **System pengecekan pembayaran & pajak** (`system_check_payment.php`) → jika berhasil, set `paid` dan simpan pajak 10% ke tabel `revenues`.
- **Pengiriman barang** (`seller_ship_item.php`) → update status revenue `ready_to_release`.
- **User konfirmasi terima barang** (`user_confirm_receive.php`) → release dana ke seller (`revenues.status='released'`) dan item `sold`.

### Skema Tabel (tambahan minimal)
Tambahkan kolom/tabel berikut (SQL ilustratif):

```sql
ALTER TABLE items 
  ADD COLUMN status VARCHAR(20) DEFAULT 'pending_legal',
  ADD COLUMN legal TINYINT(1) DEFAULT 0;

CREATE TABLE IF NOT EXISTS settings (
  id INT PRIMARY KEY DEFAULT 1,
  min_price INT DEFAULT 0,
  max_price INT DEFAULT 0
);

-- bids sudah ada: id, username, item_id, amount, status
ALTER TABLE bids 
  ADD COLUMN status VARCHAR(20) DEFAULT 'pending_seller';

CREATE TABLE IF NOT EXISTS payments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  bid_id INT NOT NULL,
  method VARCHAR(30),
  status VARCHAR(20) DEFAULT 'pending_check',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS revenues (
  id INT AUTO_INCREMENT PRIMARY KEY,
  payment_id INT NOT NULL,
  seller VARCHAR(100) NOT NULL,
  gross INT NOT NULL,
  tax INT NOT NULL,
  net INT NOT NULL,
  status VARCHAR(30) DEFAULT 'awaiting_shipment'
);

CREATE TABLE IF NOT EXISTS shipments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  payment_id INT NOT NULL,
  tracking VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```
