<?php
include 'db.php';

// Contoh struktur tabel bids: id, username, item_id, amount, status
$where = '';
if (isset($_GET['username'])) {
    $username = mysqli_real_escape_string($conn, $_GET['username']);
    $where = "WHERE username='$username'";
}
$sql = "SELECT b.*, i.name AS item_name FROM bids b LEFT JOIN items i ON b.item_id = i.id $where ORDER BY b.id DESC LIMIT 10";
$result = mysqli_query($conn, $sql);

$bids = [];
while ($row = mysqli_fetch_assoc($result)) {
    $bids[] = $row;
}
echo json_encode($bids);
?>
