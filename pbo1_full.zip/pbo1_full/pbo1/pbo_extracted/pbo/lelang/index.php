<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Website Lelang Sederhana</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <header>
        <h1>Website Lelang</h1>
        <div style="margin-top:18px;">
            <!-- <a href="https://github.com/new" target="_blank" id="github-share" style="background:#24292f;color:#fff;display:inline-flex;align-items:center;gap:8px;padding:10px 20px;border-radius:6px;font-weight:600;text-decoration:none;transition:background 0.2s;">
                <svg height="20" viewBox="0 0 16 16" width="20" fill="#fff" style="vertical-align:middle;">
                    <path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.5-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.01.08-2.12 0 0 .67-.21 2.2.82a7.65 7.65 0 0 1 2-.27c.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.11.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.19 0 .21.15.46.55.38A8.013 8.013 0 0 0 16 8c0-4.42-3.58-8-8-8z"/>
                </svg>
                Share to GitHub -->
            </a>
        </div>
    </header>
    <main>
        <!-- Form Login -->
        <section id="login-section">
            <h2>Login</h2>
            <form id="login-form">
                <label for="username">Username:</label>
                <input type="text" id="username" required>
                <label for="password">Password:</label>
                <input type="password" id="password" required>
                <label for="role">Login sebagai:</label>
                <select id="role">
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                    <option value="seller">Seller</option>
                </select>
                <button type="submit">Login</button>
                <p id="login-message"></p>
            </form>
            <p style="text-align:center;margin-top:16px;">
                Belum punya akun? <a href="signup.php" style="color:#007bff;">Daftar di sini</a>
            </p>
        </section>

        <!-- Dashboard User/Admin -->
        <section id="dashboard-useradmin" style="display:none;">
            <h2>Dashboard User/Admin</h2>
            <div style="background:#222;padding:18px;border-radius:10px;margin-bottom:18px;color:#fff;">
                <p><strong>Saldo Anda:</strong> Rp 5.000.000</p>
                <p><strong>Lelang Diikuti:</strong></p>
                <ul>
                    <li>Jam Tangan Mewah - Penawaran Anda: Rp 1.200.000</li>
                    <li>Laptop Gaming - Penawaran Anda: Rp 3.000.000</li>
                </ul>
            </div>
            <!-- ...existing auction item code... -->
            <div id="auction-content">
                <img src="images/item1.jpg" alt="Barang Lelang" id="item-image">
                <h2 id="item-title">Jam Tangan Mewah</h2>
                <p id="item-desc">Jam tangan mewah dengan desain elegan.</p>
                <p>Harga Awal: <span id="start-price">Rp 1.000.000</span></p>
                <p>Penawaran Tertinggi: <span id="highest-bid">Rp 1.000.000</span></p>
                <input type="number" id="bid-input" placeholder="Masukkan penawaran Anda">
                <button id="bid-btn">Tawar</button>
                <p id="bid-message"></p>
            </div>
            <button id="logout-btn-useradmin">Logout</button>
        </section>

        <!-- Dashboard Seller -->
        <section id="dashboard-seller" style="display:none;">
            <h2>Dashboard Seller</h2>
            <div style="background:#222;padding:18px;border-radius:10px;margin-bottom:18px;color:#fff;">
                <p><strong>Barang yang Anda jual:</strong></p>
                <ul>
                    <li>Jam Tangan Mewah - Status: Aktif</li>
                    <li>Laptop Gaming - Status: Selesai</li>
                </ul>
            </div>
            <p>Selamat datang Seller! Anda dapat mengelola barang lelang di sini.</p>
            <form id="add-item-form">
                <label for="item-name">Nama Barang:</label>
                <input type="text" id="item-name" required>
                <label for="item-desc-input">Deskripsi:</label>
                <input type="text" id="item-desc-input" required>
                <label for="item-price">Harga Awal:</label>
                <input type="number" id="item-price" required>
                <button type="submit">Tambah Barang</button>
            </form>
            <div id="seller-items">
                <h3>Daftar Barang Anda:</h3>
                <ul id="items-list"></ul>
            </div>
            <button id="logout-btn-seller">Logout</button>
        </section>
    </main>
    <script src="assets/script.js"></script>
</body>
</html>
