<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'seller') {
    header('Location: index.php');
    exit;
}
$seller = $_SESSION['username'];
$role = $_SESSION['role'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Seller</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        /* Tambahan style agar dashboard lebih rapi dan center */
        body {
            background: radial-gradient(circle at top left, #1e293b 0%, #0f172a 55%, #020617 100%);
        }
        .seller-header {
            background: linear-gradient(90deg, #007bff 0%, #181818 100%);
            color: #fff;
            padding: 38px 0 28px 0;
            text-align: center;
            font-size: 2.2rem;
            font-weight: 700;
            letter-spacing: 2px;
            margin-bottom: 0;
            border-bottom-left-radius: 32px;
            border-bottom-right-radius: 32px;
            text-shadow: 0 2px 8px rgba(0,0,0,0.3);
        }
        .seller-dashboard {
            max-width: 420px;
            margin: 48px auto;
            background: rgba(24,24,24,0.98);
            border-radius: 18px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.28);
            padding: 32px 28px;
        }
        .seller-dashboard h2 {
            margin-top: 0;
            margin-bottom: 18px;
            font-size: 1.3rem;
            font-weight: 700;
            color: #fff;
        }
        .seller-summary {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 12px;
            font-size: 1rem;
        }
        .seller-summary div {
            flex: 1;
        }
        .seller-table {
            width: 100%;
            background: #181818;
            border-radius: 8px;
            color: #fff;
            margin-bottom: 12px;
            border-collapse: collapse;
        }
        .seller-table th {
            background: #007bff;
            color: #fff;
            padding: 8px;
            font-weight: 600;
        }
        .seller-table td {
            padding: 8px;
            border-bottom: 1px solid #222;
        }
        .seller-table tr:last-child td {
            border-bottom: none;
        }
        .seller-section-title {
            margin: 18px 0 8px 0;
            font-weight: 600;
            color: #fff;
        }
        .seller-actions {
            margin-top: 18px;
            text-align: left;
        }
        .seller-actions button {
            background: linear-gradient(90deg, #007bff 0%, #222 100%);
            color: #fff;
            border: none;
            border-radius: 6px;
            padding: 10px 24px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            box-shadow: 0 2px 8px rgba(0,0,0,0.18);
            transition: background 0.2s, transform 0.2s;
        }
        .seller-actions button:hover {
            background: linear-gradient(90deg, #0056b3 0%, #333 100%);
            transform: translateY(-2px) scale(1.03);
        }
        .seller-logout {
            margin: 24px 0 0 0;
            text-align: left;
        }
        .seller-logout a {
            background: #222;
            color: #007bff;
            padding: 10px 24px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 500;
            box-shadow: 0 2px 8px rgba(0,0,0,0.12);
            transition: background 0.2s, color 0.2s;
        }
        .seller-logout a:hover {
            background: #007bff;
            color: #fff;
        }
    </style>
</head>
<body>
    <header class="seller-header">
        Selamat Datang <?php echo htmlspecialchars($seller); ?> sebagai <?php echo htmlspecialchars($role); ?>
    </header>
    <main>
        <div class="seller-dashboard">
            <h2>Dashboard Seller</h2>
            <div class="seller-summary">
                <div>
                    <div>Total Barang Dijual: <span id="total-barang">0</span></div>
                    <div>Lelang Aktif: <span id="total-aktif">0</span></div>
                </div>
                <div style="text-align:right;">
                    <div>Lelang Selesai: <span id="total-selesai">0</span></div>
                    <div>Total Pendapatan: <span id="total-pendapatan">Rp 0</span></div>
                </div>
            </div>
            <hr style="border:0;border-top:1px solid #444;margin:16px 0;">
            <div class="seller-section-title">Barang yang Anda jual:</div>
            <table class="seller-table">
                <thead>
                    <tr>
                        <th>Barang</th>
                        <th>Status</th>
                        <th>Penawaran Tertinggi</th>
                    </tr>
                </thead>
                <tbody id="seller-items-table">
                    <!-- Diisi otomatis -->
                </tbody>
            </table>
            <div class="seller-section-title">Rekomendasi Lelang Barang Anda:</div>
            <div id="seller-rekomendasi" style="display:flex;gap:16px;"></div>
            <div class="seller-actions">
                <a href="input_barang.php">
                    <button type="button">Tambah Barang Baru</button>
                </a>
            </div>
            <div class="seller-logout">
                <a href="index.php">Logout</a>
            </div>
        </div>
    </main>
    <script>
    // Fetch barang yang dijual seller (langsung, tanpa parameter)
    fetch('get_items_seller.php')
        .then(res => res.json())
        .then(items => {
            let totalBarang = items.length;
            let totalAktif = 0;
            let totalSelesai = 0;
            let totalPendapatan = 0;
            const tbody = document.getElementById('seller-items-table');
            tbody.innerHTML = '';
            if (items.length === 0) {
                tbody.innerHTML = '<tr><td colspan="3">Belum ada barang yang dijual.</td></tr>';
            } else {
                items.forEach(item => {
                    const highestBid = item.highest_bid !== undefined ? item.highest_bid : item.price || 0;
                    if (item.status === 'aktif') totalAktif++;
                    if (item.status === 'selesai') {
                        totalSelesai++;
                        totalPendapatan += parseInt(highestBid);
                    }
                    const tr = document.createElement('tr');
                    tr.innerHTML = `<td style="padding:8px;">${item.name}</td>
                                    <td style="padding:8px;">${item.status.charAt(0).toUpperCase() + item.status.slice(1)}</td>
                                    <td style="padding:8px;">Rp ${parseInt(highestBid).toLocaleString('id-ID')}</td>`;
                    tbody.appendChild(tr);
                });
            }
            document.getElementById('total-barang').textContent = totalBarang;
            document.getElementById('total-aktif').textContent = totalAktif;
            document.getElementById('total-selesai').textContent = totalSelesai;
            document.getElementById('total-pendapatan').textContent = 'Rp ' + totalPendapatan.toLocaleString('id-ID');
        });
    // Rekomendasi barang seller
    fetch('get_rekomendasi.php?seller=' + encodeURIComponent(seller))
        .then(res => res.json())
        .then(items => {
            const rekomDiv = document.getElementById('seller-rekomendasi');
            rekomDiv.innerHTML = '';
            if (items.length === 0) {
                rekomDiv.innerHTML = '<div>Tidak ada rekomendasi lelang.</div>';
            } else {
                items.forEach(item => {
                    const box = document.createElement('div');
                    box.style = "background:#181818;padding:12px;border-radius:8px;flex:1;margin-right:8px;";
                    box.innerHTML = `<img src="images/item1.jpg" alt="${item.name}" style="width:100%;border-radius:6px;"><p style="margin:8px 0 0 0;">${item.name}</p><button style="margin-top:8px;">Lihat Detail</button>`;
                    rekomDiv.appendChild(box);
                });
            }
        });
    </script>
</body>
</html>