<?php
include 'db.php';
/**
 * Admin → Menentukan Barang Legal → System Index Barang Legal
 * Request: POST item_id, legal (0/1). If legal=1 set legal=1 and status='aktif', else status='ditolak'.
 */
if ($_SERVER['REQUEST_METHOD']==='POST'){
    $item_id = intval($_POST['item_id'] ?? 0);
    $legal   = intval($_POST['legal'] ?? 0) ? 1 : 0;
    if ($item_id>0){
        if ($legal===1){
            $sql = "UPDATE items SET legal=1, status='aktif' WHERE id=$item_id";
        } else {
            $sql = "UPDATE items SET legal=0, status='ditolak' WHERE id=$item_id";
        }
        if (mysqli_query($conn,$sql)){
            echo json_encode(['success'=>true]);
        } else {
            echo json_encode(['success'=>false,'msg'=>'Gagal update status legal']);
        }
    } else {
        echo json_encode(['success'=>false,'msg'=>'item_id tidak valid']);
    }
} else {
    echo json_encode(['success'=>false,'msg'=>'Metode tidak valid']);
}
?>