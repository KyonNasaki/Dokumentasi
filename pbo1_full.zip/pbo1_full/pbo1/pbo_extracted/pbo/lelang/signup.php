<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];
    $role     = $_POST['role'];

    // Validasi sederhana
    if (empty($username) || empty($password) || empty($role)) {
        echo json_encode(['success' => false, 'msg' => 'Semua field harus diisi!']);
        exit;
    }

    // Cek username sudah ada
    $cek = mysqli_query($conn, "SELECT id FROM users WHERE username='$username' AND role='$role'");
    if (mysqli_num_rows($cek) > 0) {
        echo json_encode(['success' => false, 'msg' => 'Username sudah terdaftar untuk role ini!']);
        exit;
    }

    // Untuk produksi, gunakan password_hash!
    $query = "INSERT INTO users (username, password, role) VALUES ('$username', '$password', '$role')";
    if (mysqli_query($conn, $query)) {
        echo json_encode(['success' => true, 'msg' => 'Registrasi berhasil!']);
    } else {
        echo json_encode(['success' => false, 'msg' => 'Registrasi gagal!']);
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Signup Akun Baru</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        /* Tambahan style agar form signup lebih menarik */
        #signup-section {
            background: rgba(24,24,24,0.96);
            max-width: 420px;
            margin: 48px auto;
            padding: 32px 28px;
            border-radius: 18px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.28);
        }
        #signup-section h1 {
            text-align: center;
            color: #ffffffff;
            margin-bottom: 24px;
        }
        #signup-form label {
            color: #ffffffff;
            font-size: 0.98rem;
            margin-top: 12px;
        }
        #signup-form input, #signup-form select {
            width: 100%;
            padding: 10px 12px;
            margin-top: 7px;
            margin-bottom: 18px;
            box-sizing: border-box;
            border: 1px solid #333;
            border-radius: 8px;
            background: #181818;
            color: #fff;
            font-size: 16px;
            transition: border 0.2s;
        }
        #signup-form button {
            width: 100%;
            padding: 12px 0;
            background: linear-gradient(90deg, #2563eb 0%, #1d4ed8 100%);
            color: #f8fafc;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 17px;
            font-weight: bold;
            margin-top: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.18);
            transition: background 0.2s, transform 0.2s;
        }
        #signup-form button:hover {
            background: linear-gradient(90deg, #1d4ed8 0%, #2563eb 100%);
            transform: translateY(-2px) scale(1.03);
        }
        #signup-message {
            margin-top: 10px;
            font-size: 15px;
            text-align: center;
        }
        .signup-link {
            text-align: center;
            margin-top: 18px;
        }
        .signup-link a {
            color: #ffffffff;
            text-decoration: none;
            font-weight: 500;
        }
        .signup-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header>
        <h1 style="text-align:center;color:#2563eb;margin-top:32px;">Daftar Akun Baru</h1>
    </header>
    <main>
        <section id="signup-section">
            <form id="signup-form" method="post">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
                <label for="role">Daftar sebagai</label>
                <select id="role" name="role">
                    <option value="user">User</option>
                    <option value="seller">Seller</option>
                </select>
                <button type="submit">Daftar</button>
                <p id="signup-message"></p>
            </form>
            <div class="signup-link">
                Sudah punya akun? <a href="index.php">Login di sini</a>
            </div>
        </section>
    </main>
    <script>
    document.getElementById('signup-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const form = e.target;
        const data = new FormData(form);
        fetch('signup.php', {
            method: 'POST',
            body: data
        })
        .then(res => res.json())
        .then(result => {
            const msg = document.getElementById('signup-message');
            if (result.success) {
                msg.style.color = 'green';
                msg.textContent = result.msg + ' Silakan login.';
                setTimeout(() => { window.location = 'index.php'; }, 1500);
            } else {
                msg.style.color = 'red';
                msg.textContent = result.msg;
            }
        });
    });
    </script>
</body>
</html>
