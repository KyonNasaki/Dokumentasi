<?php
include 'db.php';
/**
 * User → Mendapatkan Barang (konfirmasi)
 * Request: POST payment_id
 * Marks revenue as 'released' (seller menerima pendapatan) and item status 'sold'.
 */
if ($_SERVER['REQUEST_METHOD']==='POST'){
    $payment_id = intval($_POST['payment_id'] ?? 0);
    if ($payment_id>0){
        mysqli_query($conn, "UPDATE revenues SET status='released' WHERE payment_id=$payment_id");
        // mark item sold
        mysqli_query($conn, "UPDATE items i 
            JOIN bids b ON b.item_id=i.id 
            JOIN payments p ON p.bid_id=b.id 
            SET i.status='sold' 
            WHERE p.id=$payment_id");
        echo json_encode(['success'=>true]);
    } else {
        echo json_encode(['success'=>false,'msg'=>'payment_id tidak valid']);
    }
} else {
    echo json_encode(['success'=>false,'msg'=>'Metode tidak valid']);
}
?>