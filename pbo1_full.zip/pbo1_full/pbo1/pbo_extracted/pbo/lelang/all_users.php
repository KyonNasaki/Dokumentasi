<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Daftar Semua User</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <header>
        <h1>Daftar Semua User</h1>
        <a href="home_admin.html" class="btn btn--ghost">Kembali ke Admin</a>
    </header>
    <main>
        <div class="table-wrapper">
            <table id="table-all-user" class="table table--hover">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Username</th>
                        <th>Role</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Diisi otomatis dari database -->
                </tbody>
            </table>
        </div>
    </main>
    <script>
    function loadAllUsers() {
        fetch('api/get_accounts.php')
            .then(res => res.json())
            .then(data => {
                const tbody = document.querySelector('#table-all-user tbody');
                tbody.innerHTML = '';
                data.users.forEach(user => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${user.nama}</td>
                        <td>${user.username}</td>
                        <td>${user.role}</td>
                        <td>
                            <button class="btn btn--table btn--danger" onclick="deleteUserSeller('user','${user.username}')">Hapus</button>
                        </td>
                    `;
                    tbody.appendChild(tr);
                });
            });
    }
    window.onload = loadAllUsers;

    window.deleteUserSeller = function(type, username) {
        if (confirm('Yakin ingin menghapus akun ini?')) {
            fetch('api/delete_account.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ role: type, username })
            })
            .then(res => res.json())
            .then(result => {
                if (result.success) {
                    alert('Akun berhasil dihapus');
                    loadAllUsers();
                } else {
                    alert('Gagal menghapus: ' + result.message);
                }
            });
        }
    };
    </script>
</body>
</html>
