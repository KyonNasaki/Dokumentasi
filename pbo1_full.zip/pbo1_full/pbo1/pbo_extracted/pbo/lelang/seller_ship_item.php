<?php
include 'db.php';
/**
 * Seller → Mengirim Barang → System update revenue status 'ready_to_release'
 * Request: POST payment_id, tracking (optional)
 */
if ($_SERVER['REQUEST_METHOD']==='POST'){
    $payment_id = intval($_POST['payment_id'] ?? 0);
    $tracking = mysqli_real_escape_string($conn, $_POST['tracking'] ?? '');
    if ($payment_id>0){
        mysqli_query($conn, "INSERT INTO shipments (payment_id, tracking) VALUES ($payment_id,'$tracking')");
        mysqli_query($conn, "UPDATE revenues SET status='ready_to_release' WHERE payment_id=$payment_id");
        echo json_encode(['success'=>true]);
    } else {
        echo json_encode(['success'=>false,'msg':'payment_id tidak valid']);
    }
} else {
    echo json_encode(['success'=>false,'msg'=>'Metode tidak valid']);
}
?>