<?php
require __DIR__.'/config.php';
require __DIR__.'/auth.php';
require_role(['admin']);
<?php
require __DIR__.'/config.php';
$errors=[];
if($_SERVER['REQUEST_METHOD']==='POST'){
  $username = trim($_POST['username'] ?? '');
  $password = trim($_POST['password'] ?? '');
  $role = $_POST['role'] ?? 'user';
  if($username==='') $errors[]='Username wajib.';
  if($password==='') $errors[]='Password wajib.';
  if(!in_array($role,['admin','user','seller'])) $errors[]='Role tidak valid.';
  if(!$errors){
    // DEMO: simpan plaintext sesuai struktur dump. Untuk produksi: hash password!
    $stmt = $pdo->prepare("INSERT INTO users (username,password,role) VALUES (:u,:p,:r)");
    $stmt->execute([':u'=>$username,':p'=>$password,':r'=>$role]);
    header('Location: users_index.php'); exit;
  }
}
$title = "Tambah User";
include __DIR__.'/header.php';
?>
  <h1><?= htmlspecialchars($title) ?></h1>
  <div class="card">
    <?php if($errors): ?><div class="muted">• <?= implode('<br>• ',array_map('htmlspecialchars',$errors)) ?></div><?php endif; ?>
    <form method="post">
      <div class="row">
        <div>
          <label>Username</label>
          <input name="username" required>
        </div>
        <div>
          <label>Password</label>
          <input name="password" required>
        </div>
      </div>
      <div class="row row-1">
        <div>
          <label>Role</label>
          <select name="role">
            <option value="admin">admin</option>
            <option value="user">user</option>
            <option value="seller">seller</option>
          </select>
        </div>
      </div>
      <button class="btn btn-primary mt-3" type="submit">Simpan</button>
      <a class="btn mt-3" href="users_index.php">Batal</a>
    </form>
  </div>
<?php include __DIR__.'/footer.php'; ?>
